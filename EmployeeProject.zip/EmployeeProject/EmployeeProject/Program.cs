﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmployeeProject
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeDetails ob = new EmployeeDetails();
           // int flag = 1;
            string EmpFile = @"C:\Users\Maa\Desktop\EmployeeDetails.txt";
            string DeptFile = @"C:\Users\Maa\Desktop\DepartmentDetails.txt";
            string ProjFile = @"C:\Users\Maa\Desktop\ProjectDetais.txt";
            while (true)
            {
                int ch;
                Console.WriteLine("1.insert employee / department / projects");
                Console.WriteLine("2.Get Employee details by department name");
                Console.WriteLine("3.search by empid in projects and return employye details");
                Console.WriteLine("4.Print Projects based on department");
                Console.WriteLine("5.Exit");
                ch = int.Parse(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        Console.WriteLine("1.insert employee 2.department 3. projects");
                        int ch1 = int.Parse(Console.ReadLine());
                        if (ch1 == 1)
                        {
                            ob.employe();
                            //string filename = @"C:\Users\Maa\Desktop\EmployeeDetails.txt";
                            StreamWriter sw = new StreamWriter(EmpFile, true);
                            using (sw)
                            {

                                sw.Write(ob.Empoutput());
                                sw.WriteLine();
                            }
                            sw.Close();
                        }
                        else if (ch1 == 2)
                        {
                            ob.department();
                          //  string filename = @"C:\Users\Maa\Desktop\Department.txt";
                            StreamWriter sw = new StreamWriter(DeptFile, true);
                            using (sw)
                            {
                                sw.Write(ob.Deptoutput());
                                sw.WriteLine();
                            }
                            sw.Close();
                        }
                        else if (ch1 == 3)
                        {
                            ob.projects();
                            //string filename = @"C:\Users\Maa\Desktop\Project.txt";
                            StreamWriter sw = new StreamWriter(ProjFile, true);
                            using (sw)
                            {
                                sw.Write(ob.Projoutput());
                                sw.WriteLine();
                            }
                            sw.Close();
                        }
                        break;
                    case 2:
                        // string filename1 = @"C:\Users\Maa\Desktop\Department.txt";
                        //FileStream fInStream = File.OpenRead(filename1);
                        //StreamReader sReader = new StreamReader(fInStream);
                       
                        Console.WriteLine("Enter Department Name");
                        string deptname = Console.ReadLine();

                        int deptid = -1;
                        if(File.Exists(DeptFile))
                        {
                            string[] lines = File.ReadAllLines(DeptFile);
                            foreach(string line in lines)
                            {
                                string[] words = line.Split(',');
                                if(words[1].Equals(deptname))
                                {
                                    deptid = int.Parse(words[0]);
                                }
                            }
                        }
                        if(deptid!=-1)
                        {
                            string[] lines = File.ReadAllLines(EmpFile);
                            foreach(string line in lines)
                            {
                                string[] words = line.Split(',');
                                if(int.Parse(words[4])==deptid)
                                {
                                    Console.WriteLine(words[0] + " " + words[1] + " " + words[2] + " " + words[3] + " " + words[4]);
                                }
                            }
                        }
                        break;
                    case 3:Console.WriteLine("Enter Employee id");
                        int Empid = int.Parse(Console.ReadLine());
                        if(File.Exists(EmpFile))
                        {
                            string[] lines = File.ReadAllLines(EmpFile);
                            foreach(string line in lines)
                            {
                                Console.WriteLine("Employees :");
                                string[] words = line.Split(',');
                                if(int.Parse(words[0])==Empid)
                                {
                                    Console.WriteLine(words[0] + " " + words[1] + " " + words[2] + " " + words[3] + " " + words[4]);
                                }
                            }
                           
                         }
                        if(File.Exists(ProjFile))
                        {
                            string[] lines = File.ReadAllLines(ProjFile);
                            foreach (string line in lines)
                            {
                                Console.WriteLine("Projects :");
                                string[] words = line.Split(',');
                                if (int.Parse(words[3]) == Empid)
                                {
                                    Console.WriteLine(words[0] + " " + words[1] + " " + words[2] + " " + words[3]);
                                }
                            }
                        }
                        break;
                    case 4:
                        Console.Write("Enter department name: ");
                        string Deptname = Console.ReadLine();
                        int projid= -1;
                        if (File.Exists(DeptFile))
                        {
                            string[] lines = File.ReadAllLines(DeptFile);
                            foreach (string line in lines)
                            {
                                string[] words = line.Split(',');
                                if (words[1].Equals(Deptname))
                                {
                                    projid = int.Parse(words[0]);
                                }
                            }
                        }

                        if (projid != -1)
                        {
                            string[] lines = File.ReadAllLines(ProjFile);
                            foreach (string line in lines)
                            {
                                string[] words = line.Split(',');
                                if (int.Parse(words[2]) == projid)
                                {
                                    Console.WriteLine(words[0] + " " + words[1] + " " + words[2] + " " + words[3]);
                                }
                            }
                        }
                        break;
                    case 5:return;
                    default: Console.WriteLine("Enter the correct input"); break;

                }
            }
        }
    } 
}

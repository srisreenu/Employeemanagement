﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace EmployeeProject
{
    class Program2
    {
        static void Main(string[] args)
        {
           /* string EmpFile = @"C:\Users\Maa\Desktop\EmployeeDetails.txt";
          //  Console.Write("Enter department name: ");
            string Deptname = Console.ReadLine();
            // int projid = -1;
            if (File.Exists(EmpFile))
            {
               // string lines = File.ReadAllLines(EmpFile);
                string[] words = lines.Split(' ');
                foreach (string line in words)
                {
                   // string[] words = line.Split(' ');
                    /* if (words[1].Equals(Deptname))
                     {
                         projid = int.Parse(words[0]);
                     }*/
                   // Console.WriteLine($"<{words}>");
                //}
            //}
            /* if (File.Exists(textFile))
             {
               //  StreamReader streamReader = new StreamReader(textFile);
                  string s = File.ReadAllText(textFile);
                 //string s = streamReader.ReadToEnd();
                 string[] words = s.Split();
                 Console.WriteLine(words);
                 /* foreach (string word in words)
                  {
                      // show the resulting string in textbox2
                     Console.WriteLine(word);
                  }*/
            // Read file using StreamReader. Reads file line by line  
            // using (StreamReader file = new StreamReader(textFile))
            //{
            /* int counter = 0;
             string ln;

             while ((ln = file.ReadLine()) != null)
             {
                 Console.WriteLine(ln);
                 counter++;
             }
             file.Close();*/




        }
    }
}
       

